<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Director | PPC 5G</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N79T3LBF');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N79T3LBF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header> 
    <div class="menu">
    <div class="container">
        <ul class="menulist">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <div class="clearfix"></div>
    </div>
<div class="menu childmenu">
        <div class="container">
            <!--<ul class="firstmenu">-->
            <!--    <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal1">Why Us</a></li>-->
            <!--    <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal2">Book Aduit</a></li>-->
            <!--    <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> -->
            <!--        <ul class="submenu open1">-->
                        <!-- <div class="arrow-up"></div> -->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal3"><i class="fa fa-angle-right" aria-hidden="true"></i> Before Selecting PPC Company</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal4"><i class="fa fa-angle-right" aria-hidden="true"></i> Landing Page Mistakes</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal5"><i class="fa fa-angle-right" aria-hidden="true"></i> Discussion With PPC Experts</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal6"><i class="fa fa-angle-right" aria-hidden="true"></i> Personalized PPC Consultation</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal8"><i class="fa fa-angle-right" aria-hidden="true"></i> Reasons Why Clients Love Us?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal9"><i class="fa fa-angle-right" aria-hidden="true"></i> Exclusive PPC Additional Services?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal10"><i class="fa fa-angle-right" aria-hidden="true"></i> Types of ads we are expertise</a></li>-->
            <!--        </ul>-->
            <!--    </li>-->
            <!--</ul>-->
            <div class="clearfix"></div>
        </div>
    </div>    
</div>
</div>    <main>
        <section class="bgcontent">
            <div class="container">
                <h1>ABOUT Director</h1>
                <!-- <h4>Top-Ranked Google Ads Professionals in India</h4>
                <p>With our PPC gateway, Say goodbye to 70% budget wastage, and hello to 2x the results.</p> -->
            </div>
        </section>
        <section class="aboutus lightgrey pad20">
            <div class="container">
            <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-2">
                            <img src="images/userfemale.webp" alt="" />
                        </div>
                        <div class="col-sm-9">
                            <div class="innerdire">
                                <h3>Founder and CEO</h3>
                                <div class="directorname">Name - Gitashri</div>
                                <h5>Achievements :</h5>
                                <hr>
                                <ul>
                                    <li>Designed 50 Remarkable websites for new clients in just six months, expanding our portfolio.</li>
                                    <li>Boosted annual revenue by an impressive ₹1.5 million through innovative website design, a growth of 25%.</li>
                                    <li>Created advanced website prototypes that perfectly matched client visions, resulting in a remarkable ROI increase of 30%.</li>
                                    <li>Executed 7+ major website design projects within 12 months, showcasing our expertise and efficiency.</li>
                                    <li>Contributed to a significant ₹1 million revenue increase by providing strategic insights that enhanced our web design services by 20%.</li>
                                    <li>Achieved a remarkable milestone of 1,500+ error-free website hours in a year, ensuring utmost client satisfaction.</li>
                                    <li>Increased client retention by 20% through personalized, visually appealing website designs.</li>
                                    <li>Achieved an impressive 95% resolution rate for client requests, resolving client inquiries, highlighting our dedication to rapid and efficient solutions.</li>
                                    <li>Reduced manual processes by 40% for clients through the design and execution of tailored website solutions.</li>
                                    <li>Achieved an impressive 25% surge in organic website traffic, maximizing online visibility and engagement.</li>
                                    <li>Maintained an exceptional 99.9% website uptime, ensuring continuous online presence for our clients.</li>
                                    <li>Successfully executed website migrations resulting in improved user experiences and contributing to operational efficiency improvements.</li>
                                    <li>Collaborated on AI-driven elements, resulting in a 15% improvement in user interactions and engagement.</li>
                                    <li>Reduced troubleshooting time by 20% through the implementation of a knowledge-sharing platform, ensuring seamless functionality.</li>
                                    <li>Provided Comprehensive Training in Website Design to 500+ Companies, to become proficient in managing their online platforms.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-2">
                            <img src="images/maleuser.png" alt="" />
                        </div>
                        <div class="col-sm-9">
                            <div class="innerdire">
                                <h3>Director</h3>
                                <div class="directorname">Name - Mr. Vaibhav Mittal</div>
                                <h6>Professional Summary</h6>
                                <p>With 15 years of technology leadership experience, I am an innovative entrepreneur well-versed in all aspects of business formation, operation, finance, and management. My visionary business development skills are underpinned by a strong educational background in research and analytics. As an effective communicator and motivator, I identify and leverage team assets to achieve organizational goals.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-2">
                            <img src="images/usermale.webp" alt="" />
                        </div>
                        <div class="col-sm-9">
                            <div class="innerdire">
                                <h3>Managing & Technical Director </h3>
                                <div class="directorname">Name - Mr. Ganesh Gupta</div>
                                <h5>Skills:</h5>
                                <hr>
                                <ul>
                                    <li>Profound understanding of business and management principles, including development, resource allocation, production methods, and leadership.</li>
                                    <li>Deep technical proficiency in business analytics, utilizing project management and user interface software, digital business development, lead generation, google ads, landing pages creation.</li>
                                    <li>Motivated team player with exceptional public speaking and strong oral, written, and interpersonal communication skills.</li>
                                    <li>Innovative initiator and problem-solver, utilizing creativity, resourcefulness, and assets to overcome organizational obstacles.</li>
                                    <li>Lifelong learner committed to staying updated on current and emerging business practices, particularly within an international context.</li>
                                    <li>Attentive listener who values and incorporates team members' opinions into policy and planning.</li>
                                </ul>
                                <h5>Hobbies and Interests :</h5>
                                <hr>
                                <p>Beyond my professional commitments, I actively engage in leadership conferences, Learn New Technologies & AI, and Participate in Industry Webinars. Exploring global coffee varieties, reading, and international travel are among my personal interests.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-2">
                            <img src="images/userwomen-2.png" alt="" />
                        </div>
                        <div class="col-sm-9">
                            <div class="innerdire">
                                <h3>Founder and CEO</h3>
                                <div class="directorname">Name - Mrs. Swasthi Mittal</div>
                                <hr>
                                <ul>
                                    <li>Direct all organizational operations, policies, and objectives to maximize productivity and returns.</li>
                                    <li>Analyze complex scenarios, using creative problem-solving to turn challenges into profitable opportunities.</li>
                                    <li>Manage departmental managers, including recruitment, training, and responsibilities delegation.</li>
                                    <li>Monitor cost-effectiveness of operations and personnel, utilizing quantitative data for feedback and necessary cuts.</li>
                                    <li>Coordinate and approve budgets for various domains, including management, development, marketing, and expansion.</li>
                                    <li>Crafted impactful marketing content and sales scripts with strategic messaging.</li>
                                    <li>Led training sessions covering technologies best practices, research and analytics, customer service, branding, and international considerations.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </section>
    </main> 
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>   
<div class="directoractive">  
    <div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">PPC - Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <!--<li><a href="ppc-audit-services.php">PPC Audit Services</a></li>-->
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div></div>
   
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>   
<script src="js/commonjs.js"></script>   
</body>
</html>