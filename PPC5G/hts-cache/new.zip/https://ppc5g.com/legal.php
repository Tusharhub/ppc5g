<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legal | PPC 5G</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N79T3LBF');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N79T3LBF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header> 
    <div class="menu">
    <div class="container">
        <ul class="menulist">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <div class="clearfix"></div>
    </div>
<div class="menu childmenu">
        <div class="container">
            <!--<ul class="firstmenu">-->
            <!--    <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal1">Why Us</a></li>-->
            <!--    <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal2">Book Aduit</a></li>-->
            <!--    <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> -->
            <!--        <ul class="submenu open1">-->
                        <!-- <div class="arrow-up"></div> -->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal3"><i class="fa fa-angle-right" aria-hidden="true"></i> Before Selecting PPC Company</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal4"><i class="fa fa-angle-right" aria-hidden="true"></i> Landing Page Mistakes</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal5"><i class="fa fa-angle-right" aria-hidden="true"></i> Discussion With PPC Experts</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal6"><i class="fa fa-angle-right" aria-hidden="true"></i> Personalized PPC Consultation</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal8"><i class="fa fa-angle-right" aria-hidden="true"></i> Reasons Why Clients Love Us?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal9"><i class="fa fa-angle-right" aria-hidden="true"></i> Exclusive PPC Additional Services?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal10"><i class="fa fa-angle-right" aria-hidden="true"></i> Types of ads we are expertise</a></li>-->
            <!--        </ul>-->
            <!--    </li>-->
            <!--</ul>-->
            <div class="clearfix"></div>
        </div>
    </div>    
</div>
</div>
    <main>
        <section class="bgcontent">
            <div class="container">
                <h1>LEGAL DOCUMENT</h1>
            </div>
        </section>
        <section class="aboutus lightgrey pad20 legal">
            <div class="container">
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h3>Ministry of Corporate Affairs (CIN)</h3>
                        </div>
                        <div class="col-sm-12">
                            <div class="innerdire">
                                <img src="images/mca.jpeg" alt="Ministry of Corporate Affairs">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h3>Office </h3>
                        </div>
                        <div class="col-sm-12">
                            <div class="innerdire">
                                <img src="images/office-main-gate.jpeg" alt="Office Main Gate">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h3>Pan Number</h3>
                        </div>
                        <div class="col-sm-12">
                            <div class="innerdire">
                                <a href="#"><img src="images/pan.jpg" alt="Pan"></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="aboutdirector">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <h3>Tan Number</h3>
                        </div>
                        <div class="col-sm-12">
                            <div class="innerdire">
                                <a href="#"><img src="images/tan-number.jpg" alt="Pan"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
        </section>
    </main> 
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>  <div class="legalactive">     
<div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">PPC - Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <!--<li><a href="ppc-audit-services.php">PPC Audit Services</a></li>-->
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div></div>

   
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="js/commonjs.js"></script>      
  
</body>
</html>