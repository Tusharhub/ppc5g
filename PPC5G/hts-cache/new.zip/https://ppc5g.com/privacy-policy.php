<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRIVACY POLICY</title>
    <link rel="icon" type="image/x-icon" href="images/ppclogo.png">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap-side-modals.css">
    <link rel="stylesheet" href="css/style.css" type="text/css"/>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N79T3LBF');</script>
<!-- End Google Tag Manager -->
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N79T3LBF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <div class="progress-container">
        <div class="progress-bar" id="myBar"></div>
    </div>  
    <header class="lightbrowm">
        <div class="container">
            <div class="row">
                <div class="col-sm-2 logo">
                    <a href="index.php"><img src="images/ppclogo.png" /></a>
                </div>
                <div class="col-lg-6 col-md-9 col-sm-9">
                    <h1>Welcome to PPC5G.com</h1>
                    <p>Web5G Technology Pvt Ltd Redefines Success with Unmatched Google Ads & Advanced Tracking Mastery, with a strong presence in Delhi NCR.</p>
                </div>
                <div class="col-sm-12 col-lg-4 col-md-12">
                    <ul>
                        <li><a href="tel:9999123123"> <img alt="" src="images/phone.png" height="20px" width="20px"> 9999-123-123 (Info)</a></li>
                        <li><a href="tel:8588001122"><img alt="" src="images/phone.png" height="20px" width="20px"> 8588-001122 (PPC Support)</a></li>
                        <li><a href="tel:7777909090"><img alt="" src="images/phone.png" height="20px" width="20px"> 7777-909090 (Audit & Consultancy)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <div class="menu">
    <div class="container">
        <ul class="menulist">
            <li><a href="javascript:void(0);" class="menuicon" id="menushow"><i class="fa fa-bars" aria-hidden="true"></i> Menu</a></li>
        </ul>
        <a class="homeicon" href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a>
        <div class="clearfix"></div>
    </div>
<div class="menu childmenu">
        <div class="container">
            <!--<ul class="firstmenu">-->
            <!--    <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal1">Why Us</a></li>-->
            <!--    <li><a href="#bookaduit" class="openModalBtn" data-modal-target="modal2">Book Aduit</a></li>-->
            <!--    <li><a href="javascript:void(0);" class="menudropdown">Checklist <i class="fa fa-angle-down" aria-hidden="true"></i></a> -->
            <!--        <ul class="submenu open1">-->
                        <!-- <div class="arrow-up"></div> -->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal3"><i class="fa fa-angle-right" aria-hidden="true"></i> Before Selecting PPC Company</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal4"><i class="fa fa-angle-right" aria-hidden="true"></i> Landing Page Mistakes</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal5"><i class="fa fa-angle-right" aria-hidden="true"></i> Discussion With PPC Experts</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal6"><i class="fa fa-angle-right" aria-hidden="true"></i> Personalized PPC Consultation</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal8"><i class="fa fa-angle-right" aria-hidden="true"></i> Reasons Why Clients Love Us?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal9"><i class="fa fa-angle-right" aria-hidden="true"></i> Exclusive PPC Additional Services?</a></li>-->
            <!--            <li><a href="javascript:void(0);" class="openModalBtn" data-modal-target="modal10"><i class="fa fa-angle-right" aria-hidden="true"></i> Types of ads we are expertise</a></li>-->
            <!--        </ul>-->
            <!--    </li>-->
            <!--</ul>-->
            <div class="clearfix"></div>
        </div>
    </div>    
</div>
</div>    <main>
        <section class="privacy-policy lightgrey">
            <div class="container">
            <h2 class="main_heading">PRIVACY POLICY</h2> 
                
                <div class="default_ctn"> 
                    <h4>1. PRIVACY POLICY</h4>
                    <p>Web5G Technology Pvt Ltd, recognized as a Private Limited company, maintains its official presence at <a href="https://ppc5g.com/">www.ppc5g.com</a> on the web and using it as an online address.</p>
                    <p>At Web5G Technology Pvt Ltd, accessible from <a href="https://ppc5g.com/">www.ppc5g.com</a>, finding the customers who are interested in PPC & Google Ads Managment Services </p>
                    <p>This Privacy Policy document contains types of information that is collected and recorded by Web5G Technology Pvt Ltd company, and how we use it.</p>
                    <hr>
                    <h4>2. WHY THIS PRIVACY POLICY</h4>
                    <ul style="list-style:none; padding-left:0;">
                        <li>2.1 We want you to feel comfortable using our website.</li>
                        <li>2.2 We want you to feel secure submitting information to this website.</li>
                        <li>2.3 We want you to contact us with your questions or concerns about privacy on this website.</li>
                        <li>2.4 We want you to know that by using our website you are consenting to the collection of certain data.​</li>
                    </ul>
                    <p>This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collected in PPC5gTechnology Pvt Ltd.</p>
                    <p><b>Note:</b> This policy is not applicable to any information collected offline or via channels other than this website. If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
                    <hr>
                    <h4>3. HOW TO CONTACT US</h4>
                    <p>For all queries or issues relating to the collection or processing of your personal information by us If you have any questions regarding this Privacy Policy or the way we use your personal information, you can contact us by e-mail or telephone or by mail to:</p>
                    <p>If you have any questions about this Privacy Policy, You can contact us:</p>
                    <ul>
                        <li><b>By email:</b> <a href="mailto:info@ppc5g.com">info@ppc5g.com</a></li>
                        <li><b>By phone number</b><a href="tel:9999123123">+91 9999-123-123</a></li>
                        <li><b>By visiting at address:</b> 626, 6th Floor, Signature Global Mall, Sector - 3, Vaishali, Ghaziabad, Uttar Pradesh -201010</li>
                    </ul>
                    <hr>
                    <h4>4. CONSENT POLICY</h4>
                    <p>By using our website, you hereby consent to our privacy policy and agree to its terms.</p>
                    <p>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.</p>
                    <p>If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.</p>
                    <hr>
                    <h4>5. DATA PRIVACY AND SECURITY</h4>
                    <p>We prioritize the privacy and security of user data and implement appropriate measures to protect personal information.</p>
                    <p>While using our service, We may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to:</p>
                    <p><b>5.1 Types of Data Collected:</b></p>
                    <ul>
                        <li>Email address</li>
                        <li>First name and last name</li>
                        <li>Phone number</li>
                        <li>Address, State, Province, ZIP/Postal code, City</li>
                    </ul>
                    <p><b>5.2 How Long Will We Keep Your Personal Information?</b></p>
                    <p>We will retain your personal information for no longer than is necessary for the purposes for which the personal information is processed. The length of time we hold on to your personal information will vary according to what that information is and the reason for which it is being processed.</p>
                    <p>To decide how long we should keep your personal information, we consider factors such as the kind of information, how sensitive it is, the risk of unauthorized use or disclosure, why we collect it, and if there are other ways to achieve our goals.</p>
                    <hr>
                    <h4>6. DATA SECURITY</h4>
                    <p>We have implemented security measures to safeguard your personal information.</p>
                    <p>These measures aim to prevent accidental loss, unauthorized access, alteration, or disclosure of your information. Access to your personal information is limited to individuals and entities who have a legitimate business need to know.</p>
                    <p>For more information about the specific security measures we have in place, you can contact us at any point of time.</p>
                    <hr>
                    <h4>7. YOUR RIGHTS</h4>
                    <p>The rights may only apply in certain circumstances and are subject to certain exemptions. Please see the table below for a summary of your rights. You can exercise these rights using the contact details below.</p>
                    <p><b>7.1 Right of Access to Your Personal Information:</b></p>
                    <p>You have the right to receive a copy of your personal information that we hold about you, subject to certain exemptions.</p>
                    <p>We may require further information in order to respond to your request (for instance, evidence of your identity and information to enable us to locate the specific personal information you require).</p>
                    <p><b>7.2 Right to Rectify Your Personal Information:</b></p>
                    <p>You have the right to ask us to correct your personal information that we hold where it is incorrect or incomplete.</p>
                    <p><b>7.3 Right to Erasure of Your Personal Information:</b></p>
                    <p>You have the right to ask that your personal information be deleted in certain circumstances.<br> <b>For example:</b> </p>
                    <ul>
                        <li>Where your personal information is no longer necessary in relation to the purposes for which they were collected or otherwise used;</li>
                        <li>if you withdraw your consent and there is no other legal ground for which we rely on for the continued use of your personal information;</li>
                        <li>if you object to the use of your personal information (as set out below);</li>
                        <li>if we have used your personal information unlawfully; or</li>
                        <li>if your personal information needs to be erased to comply with a legal obligation.</li>
                    </ul>
                    <p><b>7.4 Right to Restrict The Use of Your Personal Information:</b></p>
                    <p>You have the right to put on hold to use your personal information in certain circumstances. <br> <b>For example:</b></p>
                    <ul>
                        <li>Where you think your personal information is inaccurate and only for such a period to enable us to verify the accuracy of your personal information</li>
                        <li>We no longer need your personal information, but your personal information is required by you for the establishment, exercise or defence of legal claims; or</li>
                    </ul>
                    <p><b>7.5 Right to Withdraw Consent:</b></p>
                    <p>You have the right to withdraw your consent at any time where we rely on consent to use your personal information.</p>
                    <p><b>7.6 Right to Complain to The Relevant Data Protection Authority:</b></p>
                    <p>You have the right to complain to the relevant Data Protection Authority where you think we have not used your personal information in accordance with data protection law</p>
                    <hr>
                    <h4>8. NO ASSOCIATION WITH RELEVANT BRANDS AND COMPANIES</h4>
                    <p>This landing page is not associated with or endorsed by the relevant brands and companies mentioned. The use of their names, logos, trademarks, or images is for descriptive purposes only and does not imply any affiliation or endorsement.</p>
                    <hr>
                    <h4>9. NO PARTNERSHIP OR ENDORSEMENT</h4>
                    <p>The presence of other brands, logos, or trademarks on this landing page does not imply partnership, endorsement, or affiliation unless explicitly stated.</p>
                    <hr>
                    <h4>10. TRANSPARENT COMMUNICATION</h4>
                    <p>We maintain transparent communication with brand owners to ensure compliance and resolve any concerns regarding the content on this landing page.</p>
                    <hr>
                    <h4>11. NO COUNTERFEIT PRODUCTS</h4>
                    <p>We do not promote or sell counterfeit or unauthorized products on this landing page.</p>
                    <hr>
                    <h4>12. OUR OPERATIONS INVOLVE THE USE OF THIRD-PARTY VENDORS:</h4>
                    <p><b>12.1 Google Ads (AdWords) remarketing service is provided by Google Inc</b></p>
                    <ul>
                        <li>You can opt-out of Google Analytics for Display Advertising and customise the Google Display Network ads by visiting the Google Ads Settings page: http://www.google.com/settings/ads</li>
                        <li>Google also recommends installing the Google Analytics Opt-out Browser Add-on – https://tools.google.com/dlpage/gaoptout – for your web browser. Google Analytics Opt-out Browser Add-on provides visitors with the ability to prevent their data from being collected and used by Google Analytics.</li>
                        <li>For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy</li>
                    </ul>
                    <p><b>12.2 Analytics</b></p>
                    <ul>
                        <li>We may use third-party Service providers to monitor and analyze the use of our Service.</li>
                        <li>Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network.</li>
                        <li>For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy</li>
                    </ul>
                    <hr>
                    <h4>13. CHILDREN’S PRIVACY</h4>
                    <p>Our Services are not intended for use by children under the age of 18 (“Child” or “Children”). We do not knowingly collect personally identifiable information from Children under 18. If you become aware that a Child has provided us with Personal Data, please contact us. </p>
                    <hr>
                    <h4>Contact Us</h4>
                    <ul>
                        <li><b>By email:</b> <a href="mailto:info@ppc5g.com">info@ppc5g.com</a></li>
                        <li><b>By phone number</b><a href="tel:9999123123">+91 9999-123-123</a></li>
                        <li><b>By visiting at address:</b> 626, 6th Floor, Signature Global Mall, Sector - 3, Vaishali, Ghaziabad, Uttar Pradesh -201010</li>
                    </ul>
                </div>
             </div>    
        </section>
    </main>
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4 footerfirst">
                <h3>Connect with Our Team</h3>
                <h5>General Inquiries</h5>
                <ul>
                    <li><a href="tel:9999123123"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 9999-123-123</a></li>
                    <li><a href="mailto:info@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: info@ppc5g.com</a></li>
                </ul>
                <h5>PPC Support Team</h5>
                <ul>
                    <li><a href="tel:8588001122"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 8588-001122</a></li>
                    <li><a href="mailto:support@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: support@ppc5g.com</a></li>
                </ul>
                <h5>PPC Audit & Consultancy</h5>
                <ul>
                    <li><a href="tel:7777909090"><i class="fa fa-phone" aria-hidden="true"></i> Phone: 7777-909090</a></li>
                    <li><a href="mailto:audit@ppc5g.com"><i class="fa fa-envelope" aria-hidden="true"></i> Email: audit@ppc5g.com</a></li>
                </ul>
            </div>
            <div class="col-sm-4 footerfirst">
                <h3>Contact with Us</h3>
                <ul>
                <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 626, 6th Floor, Signature Global Mall,<br>Sector-3, Vaishali, Ghaziabad,<br> Uttar Pradesh-201010</a></li>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.4736342932583!2d77.3329667742235!3d28.645533783492468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x64662107506a59b3%3A0x1952eb50974829ec!2sWeb5G%20Technology%20Private%20Limited!5e0!3m2!1sen!2sin!4v1695913605459!5m2!1sen!2sin" width="100%" height="220" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </ul>
            </div>
        </div>
    </div>
    <div class="copyright">
        <p>© 2023 PPC5G Technology Pvt. Ltd. All Right Reserved.</p>
    </div>
</footer>   
<div class="privacyactive">  
<div class="menu_overlay">
    <div id="menuopen" class="menuslide">
        <img src="images/ppclogo.png" alt="" />
        <span class="comtitle">Web5G Technology Pvt. Ltd</span>
        <button id="menuclose"><i class="fa fa-times" aria-hidden="true"></i>   </button>
        <div class="menu_body">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="ppc-services.php">PPC - Google Ads Services</a></li>
                <li><a href="landing-page.php">Landing Page Design Services</a></li>
                <li><a href="website-design.php">Website Design Services</a></li>
                <!--<li><a href="ppc-audit-services.php">PPC Audit Services</a></li>-->
                <li><a href="javascript:void(0);" class="slidedownmenu">About Us<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul class="slidemenu">
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="about-director.php">About Director</a></li>
                    </ul>
                </li>
                <li><a href="legal.php">Legal</a></li>
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
            </ul>
        </div>
    </div>
</div></div>

   
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="js/commonjs.js"></script>      
  
</body>
</html>